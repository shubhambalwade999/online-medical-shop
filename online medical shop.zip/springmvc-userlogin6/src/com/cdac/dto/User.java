package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "user")
public class User {
	
	@Id
	@GeneratedValue
	//@Column(name = "user_id")
	//private int userId;
	
	@Column(name="cust_id")
	private int custId;
	
	@Column(name = "first_name")
	private String FirstName;
	@Column(name = "last_name")
	private String LastName;
	@Column(name = "user_name")
	private String userName;

	@Column(name = "user_pass")
	private String userPass;

	@Column(name = "email_id")
	private String EmailId;
	@Column(name = "gender")
	private String Gender;
	@Column(name = "age")    
	private int Age;  
	                               
	
	@Column(name="phone")
	private long phoneNo;
	@Column(name = "city")
	private String City;
	@Column(name = "pincode")
	private String Pincode;
	
	public User() {
		
	}
	

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPass() {
		return userPass;
	}

	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

	

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String city) {
		City = city;
	}

	public String getPincode() {
		return Pincode;
	}

	public void setPincode(String pincode) {
		Pincode = pincode;
	}

	@Override
	public String toString() {
		return "User [custId=" + custId + ", FirstName=" + FirstName + ", LastName=" + LastName + ", userName=" + userName + ", userPass=" + userPass
				+ ",Gender="+ Gender+" Age=" + Age + ", EmailId" + EmailId + ", phoneNo=" + phoneNo + ", City=" + City + ",Pincode="+ Pincode +"]";
	}
	
}


