package com.cdac.dao;

import com.cdac.dto.User;
//import com.cdac.dto.Login;

public interface UserDao {
	void insertUser(User user);

	  boolean loginUser(User user);

	String forgotPassword(String userName);

}
