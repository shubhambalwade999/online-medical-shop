package com.cdac.cntr;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;
import com.cdac.dto.Expense;
import com.cdac.dto.User;
import com.cdac.service.AdminService;
import com.cdac.service.ExpenseService;
import com.cdac.service.UserService;

@Controller
public class AdminController {
	
	@Autowired
	private AdminService adminService;
	
	@Autowired
	private ExpenseService expenseService;

	@RequestMapping(value = "/prep_adminreg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("admin", new Admin()); 
		return "adminreg_form";
	}
	

	@RequestMapping(value = "/adminreg.htm",method = RequestMethod.POST)
	public String register(Admin admin,ModelMap map) {
		adminService.insertAdmin(admin);
		return "index";
	}
	@RequestMapping(value = "/prep_adminlog_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		
		
		map.put("admin", new Admin());
		return "adminlog_form";
	}
	
	@RequestMapping(value = "/adminlogin.htm",method = RequestMethod.POST)
	public String login(Admin admin,ModelMap map,HttpSession session) {
		boolean b = adminService.loginAdmin(admin);
		if(b) {
			
			session.setAttribute("admin", admin);
			return "home1";
		}else {
			map.put("admin", new Admin());
			return "adminlog_form";
		}
	}
	
//	public static boolean checkSessionStudent(HttpSession hs,HttpServletResponse r) throws IOException {
//		Object s1 = hs.getAttribute("User");
//		if(s1 == null) {
//			r.sendRedirect("./");
//			return false;
//		}
//		return true;
//	}
	
	
	@RequestMapping(value = "/prep_exp_add.htm",method = RequestMethod.GET)
	public String prepExpenseAddForm(ModelMap map , HttpSession session,HttpServletResponse r) throws IOException {
		

		map.put("expense", new Expense());
		return "addexpform";
	}
	@RequestMapping(value = "/expense_add.htm",method = RequestMethod.POST)
	public String expenseAdd(Expense expense,HttpSession session,HttpServletResponse r) throws IOException {
		
		int userId = 0;
		expense.setUserId(userId); 
		expenseService.addExpense(expense);
		return "home1";
	}
	
	@RequestMapping(value = "/ExpenseList.htm",method = RequestMethod.GET)
	public String allPack(ModelMap map,HttpSession session) {
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		List<Expense> li = expenseService.selectAll();
		System.out.println(li);
		map.put("eList", li);
		
		return "expense_list";
	}
  

	@RequestMapping(value = "/expense_delete.htm",method = RequestMethod.GET)
	public String expenseDelete(@RequestParam int expenseId,ModelMap map,HttpSession session) {
		
		expenseService.removeExpense(expenseId); 
		
		//int userId = ((User)session.getAttribute("user")).getCustId();
		List<Expense> li = expenseService.selectAllExp();
		map.put("eList", li);
		return "expense_list";
	}
	
	@RequestMapping(value = "/update_form.htm",method = RequestMethod.GET)
	public String expenseUpdateForm(@RequestParam int expenseId,ModelMap map) {
		
		Expense exp = expenseService.findExpenxe(expenseId);
		map.put("expense", exp);
		
		return "expense_update_form";
	}
	
	@RequestMapping(value = "/expense_update.htm",method = RequestMethod.POST)
	public String expenseUpdate(Expense expense,ModelMap map,HttpSession session) {
		
		int userId = 0;
		expense.setUserId(userId);
		expenseService.modifyExpense(expense);
			
		List<Expense> li = expenseService.selectAllExp();
		map.put("eList", li);
		return "expense_list";
	}
	
	@RequestMapping(value="/AdminLogout.htm", method= RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "index";
	}

}



