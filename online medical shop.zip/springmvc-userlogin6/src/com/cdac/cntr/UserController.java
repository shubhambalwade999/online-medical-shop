package com.cdac.cntr;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.cdac.dto.Expense;
import com.cdac.dto.User;
import com.cdac.service.ExpenseService;
import com.cdac.service.UserService;
@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private MailSender mailSender;
	
	@Autowired
	private ExpenseService expenseService;
	
	@RequestMapping(value = "/prep_reg_form.htm",method = RequestMethod.GET)
	public String prepRegForm(ModelMap map) {
		map.put("user", new User()); 
		//System.out.println("ghghghgjj");
		return "reg_form";
	}
	
	@RequestMapping(value = "/reg.htm",method = RequestMethod.POST)
	public String register(User user,ModelMap map) {
		userService.addUser(user);
		return "index";
	}
	
	@RequestMapping(value = "/prep_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("user", new User());
		return "login_form";
	}
	
	@RequestMapping(value = "/login.htm",method = RequestMethod.POST)
	public String login(User user,ModelMap map,HttpSession session) {
		boolean b = userService.loginUser(user);
		if(b) {
			
			session.setAttribute("user", user);
			return "home";
		}else {
			map.put("user", new User());
			return "login_form";
		}
	}
	
//	@RequestMapping(value = "/UserList.htm",method = RequestMethod.GET)
//	public String allPack(ModelMap map,HttpSession session) {
//		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
//		List<Expense> li = expenseService.selectAllExp();
//		System.out.println(li);
//		map.put("eList", li);
//		
//		return "expense_list";
//	}
	
	
	@RequestMapping(value = "/expuserList.htm",method = RequestMethod.GET)
	public String allPack(ModelMap map,HttpSession session) {
		System.out.println("hiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii");
		List<Expense> li = expenseService.selectAll();
		System.out.println(li);
		map.put("explist", li);
		
		return "expavailable";
	}
	
	
	
	//forgot_password.htm
	@RequestMapping(value = "/forgot_password.htm",method = RequestMethod.POST)
	public String forgotPassword(@RequestParam String EmailId,ModelMap map) {		
		String pass = userService.forgotPassword(EmailId);
		String msg = "you are not registered";
		if(pass!=null) {	
			
			SimpleMailMessage message = new SimpleMailMessage();  
	        message.setFrom("shivanikondhekar19@gmail.com");  
	        message.setTo(EmailId);  
	        message.setSubject("Your password");  
	        message.setText(pass);  
	        //sending message   
	        mailSender.send(message);
			msg = "check the mail for password";
		}
		map.put("msg", msg);
		return "info";
	}
	

	@RequestMapping(value="/addtoCartUser.htm", method= RequestMethod.GET)
	public String addtoCart(HttpSession session, int expenseId,Expense expense ) {
		int userId=((User)session.getAttribute("user")).getCustId();
		expenseId=((Expense)session.getAttribute("expense")).getExpenseId();
		expense= expenseService.findExpenxe(expenseId);
		
		expense.setUserId(userId);
		expenseService.addExpense(expense);
		return "home";
	}
	
	@RequestMapping(value="/UserLogout.htm", method= RequestMethod.GET)
	public String logout(HttpSession session) {
		session.removeAttribute("User");

		session.invalidate();
		return "index";
	}
	


}

