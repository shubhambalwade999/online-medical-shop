package com.cdac.service;

import com.cdac.dto.Admin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.AdminDao;
//import com.cdac.dto.Admin;
@Service

public class AdminServiceImple implements AdminService{

	@Autowired
	private AdminDao adminDao;
	@Override
	public void insertAdmin(Admin admin) {
		adminDao.insertAdmin(admin);
	}

	@Override
	public boolean loginAdmin(Admin admin) {
		return adminDao.loginAdmin(admin);
		
	}

	
}
