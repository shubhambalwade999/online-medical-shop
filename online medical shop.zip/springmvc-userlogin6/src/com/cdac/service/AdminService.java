package com.cdac.service;

import com.cdac.dto.Admin;

public interface AdminService {
	
	void insertAdmin(Admin admin);

	  boolean loginAdmin(Admin admin);

}
